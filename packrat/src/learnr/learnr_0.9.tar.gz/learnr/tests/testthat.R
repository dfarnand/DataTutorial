library(testthat)
library(learnr)

test_check("learnr")
